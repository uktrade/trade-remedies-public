from .version import __version__

__author__ = "Harel Malka"
__email__ = "harel@harelmalka.com"
